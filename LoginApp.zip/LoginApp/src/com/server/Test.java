package com.server;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
/**
 * Servlet implementation class LoginApp
 */
@WebServlet("/LoginApp")
public class Test extends HttpServlet {


	private static final long serialVersionUID = 1L;
	private String cc;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {



		response.setContentType("text/html");
		cc = request.getParameter("cc");

		RequestDispatcher rd = null;

		PrintWriter out = response.getWriter();
		BusinessLogic logic = new BusinessLogic();
		Card creditCard = logic.CheckCardValidity(cc);


		RequestDispatcher dispatcher = request.getRequestDispatcher("success.jsp");
		request.setAttribute("creditCard", creditCard);

		dispatcher.forward(request, response);

	}

}
