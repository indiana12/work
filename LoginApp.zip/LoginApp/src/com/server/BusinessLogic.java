package com.server;

import java.util.ArrayList;
//import java.util.HashMap;

public class BusinessLogic {
	
//	final String[] cardTypes = { 'Visa', 'Rupay', 'Mastero', 'Citi' };

	
	public Card CheckCardValidity(String cardNumber) {
		Integer[] cardNumberArr = this.convertCardNumberToNumericArray(cardNumber);
		Card cc;
		
		if(this.cardValidate(cardNumberArr)) {
			cc = new Card(cardNumber, this.getBankName(cardNumberArr), this.getCardType(cardNumberArr), this.cardValidate(cardNumberArr));
		}
		else {
			cc = new Card( cardNumber, false);
		}
		return cc;
	}
	
	public Integer[] convertCardNumberToNumericArray(String cardNumber) {
		
		char[] tempCharArr = cardNumber.toCharArray();
		
		ArrayList<Integer> tempNumArr = new ArrayList<>();
		
		for(char data: tempCharArr) {
			tempNumArr.add(Character.getNumericValue(data));	
		}
		
		return tempNumArr.toArray(new Integer[tempNumArr.size()]);
	}
	
	public boolean cardValidate(Integer[] cardNumberArr) {
	 
		int sum=0;
		
		for( int i=0; i < cardNumberArr.length; i+=2) {
			 sum += cardNumberArr[i]*2;
		}
		
		return (sum%10 == 0)? true: false;
	}
	
	public static boolean isBetween(int x, int lower, int upper) {
		return lower <= x && x <= upper;
	}
	
	public String getCardType(Integer[] cardNumberArr) {
		
		switch(cardNumberArr[0]) {
		
		case 4:
			return "Visa";
		case 5:
			return "Rupaye";
		case 6:
			return "Mastero";
		case 7:
			return "Citi";		
		default:
			return null;
		}
			
	}
	
	
	public String getBankName(Integer[] cardNumberArr) {
		int sum=0;

		for(int i=0;i<4;i++) {
			sum += cardNumberArr[i];
		}
		
		if(sum >= 0 && sum <= 5)
			return "State Bank of India(SBI)";
		else if(sum > 5 && sum <=10 )
			return "City Bank";
		else if(sum > 10 && sum <= 15)
			return "ICICI Bank";
		else if(sum > 15 && sum <= 20)
			return "Kotak bank";
		else
			return null;

	}

}
