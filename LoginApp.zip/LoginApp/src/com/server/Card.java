package com.server;

public class Card {
	private String cardNumber;
	private String bankName;
	private String cardType;
	private boolean valid;
	
	
	public Card() {
		
	}
public Card(int x) {
		
	}

	
	
	public Card(String cardNumber, String bankName, String cardType, boolean valid) {
//		super();
		this.cardNumber = cardNumber;
		this.bankName = bankName;
		this.cardType = cardType;
		this.valid = valid;
	}

	public Card(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	
	public Card(String cardNumber, boolean valid) {
		this.cardNumber = cardNumber;
		this.valid = valid;
	}
	
	public String getBankName() {
		return bankName;
	}
	
	public String getCardType() {
		return cardType;
	}
	
	public String getCardNumber() {
		return cardNumber;
	}
	
	public boolean getValid() {
		return valid;
	}
	
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	
	public void setValid(boolean valid) {
		this.valid = valid;
	}

	@Override
	public String toString() {
		return "Card [cardNumber=" + cardNumber + ", bankName=" + bankName + ", cardType=" + cardType + ", valid="
				+ valid + "]";
	}
	
	

}
class t extends Card
{
	
}
